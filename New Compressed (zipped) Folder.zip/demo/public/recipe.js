document.addEventListener("DOMContentLoaded", () => {
  const stars = document.querySelectorAll(".star");
  const canvas = document.querySelector(".line");
  const context = canvas.getContext("2d");
  const chef = new Image();
  chef.src = "chef.png";

  chef.onload = function () {
    context.drawImage(chef, 2, 2, 150, 145);
  };

  function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
  }

  function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
  }

  stars.forEach((star) => {
    star.addEventListener("click", () => {
      const value = star.getAttribute("data-value");

      // Remove selected class from all stars
      stars.forEach((s) => s.classList.remove("selected"));

      // Add selected class to the clicked star and all previous stars
      star.classList.add("selected");
      let previousStar = star.previousElementSibling;
      while (previousStar) {
        previousStar.classList.add("selected");
        previousStar = previousStar.previousElementSibling;
      }

      // Log the rating value to the console
      console.log("Rating selected:", value);
    });
  });

  // Expose openNav and closeNav to the global scope
  window.openNav = openNav;
  window.closeNav = closeNav;
});
