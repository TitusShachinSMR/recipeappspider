document.addEventListener("DOMContentLoaded", () => {
  let ingredientInstant;
  const finalingredients = [];
  let recipe;
  let rating;
  let recipeid;
  const savedrecipe = [];
  // for getting the user id
  const userId = window.location.pathname.split("/").pop();

  //for creating link for upload page using user id
  document.getElementById("postlink").href = `/upload/${userId}`;

  document.querySelector(".userid").textContent = "USER ID: " + userId;
  // making the side nav button interractive
  const opennav = document.getElementById("mySidenav");
  const openbtn = document.querySelector(".openbtn");
  const closebtn = document.querySelector(".closebtn");
  openbtn.addEventListener("click", (e) => {
    opennav.style.width = "250px";
  });
  closebtn.addEventListener("click", (e) => {
    opennav.style.width = "0";
  });
  //giving background for recipeimage
  document.querySelector(".backgroundforrecipeimage").style.backgroundImage =
    'url("../backgroundforrecipeimage.jpg")';
  const ingredienttype = document.querySelectorAll(".ingtype");
  // Fetching type of ingredients data
  //based on the category of the the ingredients chose
  ingredienttype.forEach((button) => {
    button.addEventListener("click", (event) => {
      const type = event.target.textContent;

      fetch("/ingredients/" + type)
        .then((response) => response.json())
        .then((data) => {
          const checklist = document.querySelector(".ingredientslist");
          // Clear existing content before appending new checkboxes
          checklist.innerHTML = "";

          data.forEach((ingredient) => {
            const checkbox = document.createElement("input");
            checkbox.type = "checkbox";
            checkbox.id = ingredient.ingredient;
            checkbox.name = "ingredient";
            checkbox.value = ingredient.ingredient;
            checkbox.classList.add("checkbox");
            checkbox.style.width = "100px";
            checkbox.style.height = "30px";
            const label = document.createElement("label");
            label.style.fontWeight = "bold";
            label.htmlFor = ingredient.ingredient;
            label.textContent = ingredient.ingredient;

            const br = document.createElement("br");
            checklist.style.maxHeight = "400px";
            checklist.style.overflowY = "auto";
            checklist.style.color = "white";
            checklist.style.backgroundColor = "rgba(0, 0, 0, 0.849)";
            checklist.appendChild(checkbox);
            checklist.appendChild(label);
            checklist.appendChild(br);
          });
          ingredientInstant = document.querySelectorAll(".checkbox");
        })
        .catch((error) => console.error("Error fetching ingredients:", error));
    });
  });

  //doubleclick to remove ingredients from container(you can delete the selected ingredients in card on double click)
  function doubleclick() {
    document.querySelectorAll(".chosen").forEach((div) => {
      div.addEventListener("dblclick", function () {
        this.remove();
      });
    });
  }
  //making top button interactive to scroll the page to top
  document.querySelector(".top").addEventListener("click", (e) => {
    window.scrollTo({
      top: document.querySelector(".ingredientscontainer").offsetTop,
      behavior: "smooth",
    });
  });
  //search - getting top 5  results of the ingredients which is typed in the search container
  document.querySelector(".search").addEventListener("input", function () {
    const query = this.value;

    fetch(`/search?q=${query}`)
      .then((response) => response.json())
      .then((data) => {
        const resultsContainer = document.querySelector(".search-results");
        resultsContainer.style.display = "block";
        resultsContainer.style.zIndex = "3";
        resultsContainer.innerHTML = "";
        data.slice(0, 5).forEach((item) => {
          const li = document.createElement("li");
          li.textContent = item.ingredient;
          li.classList.add("listed");
          resultsContainer.appendChild(li);
        });

        // Add click event listeners to the newly created list items
        document.querySelectorAll(".listed").forEach((li) => {
          li.addEventListener("click", (event) => {
            const item = document.createElement("div");
            item.classList.add("chosen");
            item.textContent = li.textContent; // Add ingredient name to the selected item
            document.querySelector(".choseingredients").appendChild(item);
            doubleclick();
          });
        });
      })
      .catch((error) => console.error("Error:", error));
  });
  //for removing the search result container if the the mouse click somewhere else
  document.addEventListener("click", function (event) {
    // Check if the click event target is not the container or a child of the container
    if (!document.querySelector(".searchcontainer").contains(event.target)) {
      // Click is outside the container
      document.querySelector(".search-results").style.display = "none";
      // Execute desired logic here
    }
  });

  // Move checked items to cart
  const chosenIngredients = document.querySelector(".choseingredients");
  const addtocart = document.querySelector(".addtocart");
  addtocart.addEventListener("click", (event) => {
    ingredientInstant.forEach((checkbox) => {
      if (checkbox.checked) {
        const cell = document.createElement("div");
        cell.textContent = checkbox.value;
        cell.classList.add("chosen");
        cell.style.fontWeight = "bold";
        cell.style.backgroundColor = "rgba(255, 255, 255, 0.726)";
        cell.style.color = "black";
        cell.style.cursor = "pointer";
        chosenIngredients.appendChild(cell);
        doubleclick();
        if (!finalingredients.includes(cell.textContent)) {
          finalingredients.push(cell.textContent);
        }
      }
    });
  });

  // Making the cuisines div interactive
  const cuisineDiv = document.querySelector(".cuisine");
  const optionsContainer = document.querySelector(".options-container");

  cuisineDiv.addEventListener("click", () => {
    optionsContainer.classList.toggle("active");
  });

  // Making the cuisine clicked to get into the button
  const cuisine = [];
  const cuisinelist = document.querySelectorAll("input[name='cuisine']");

  // Making the preparation time container interactive
  let timefinalised;
  const prepartiontimediv = document.querySelector(".preparationtime");
  const timeoptioncontainer = document.querySelector(
    ".preparationtimecontainer"
  );
  prepartiontimediv.addEventListener("click", () => {
    timeoptioncontainer.classList.toggle("active");
  });
  const preparationtimelist = document.querySelectorAll(".time");
  preparationtimelist.forEach((object) => {
    object.addEventListener("click", (e) => {
      prepartiontimediv.textContent =
        "Preparation Time : " + e.target.textContent;
      timefinalised = parseInt(e.target.textContent);
      console.log(typeof timefinalised);
      timeoptioncontainer.classList.remove("active");
    });
  });

  // Handling dietary restrictions
  const diet = [];
  const dietaryrestriction = document.querySelector(".dietaryrestriction");
  const dietcontainer = document.querySelector(".dietcontainer");
  dietaryrestriction.addEventListener("click", () => {
    dietcontainer.classList.toggle("active");
  });
  const dietlist = document.querySelectorAll("input[name='diet']");
  // Function to handle posting a comment

  let currentrecipe;
  function addRecipeClickListeners() {
    const recipes = document.querySelectorAll(".recipe");
    const showrecipe = document.querySelector(".showrecipe");

    recipes.forEach((object) => {
      object.addEventListener("click", async (event) => {
        window.speechSynthesis.cancel();
        showrecipe.style.display = "block";
        document.querySelector(".heart-button").style.display = "block";
        const recipeId = object.getAttribute("data-recipe-id");
        recipeid = recipeId;
        try {
          const response = await fetch(`/recipe/${recipeId}`);
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          data = await response.json();
          console.log(data);
          data = Array.from(data);
          console.log(data);
          const recipetitle = document.querySelector(".recipetitle");
          recipetitle.textContent = data[0].name;
          const recipeimage = document.querySelector(".recipeimage");
          let img = document.createElement("img");
          img.src = `${data[0].image_path}`;
          img.alt = "recipe image";
          img.width = 200;
          img.height = 150;
          recipeimage.innerHTML = "";
          recipeimage.appendChild(img);
          const recipesteps = document.querySelector(".procedure");
          recipesteps.style.fontWeight = "bold";

          recipesteps.textContent = data[0].steps;
          const comments = document.querySelector(".commentsfordish");
          comments.innerHTML = ""; // Clear previous comments
          const commentarray = [
            ...new Set(
              data.map((item) => `${item.username}:  ${item.comment}`)
            ),
          ]; // for removing the duplicate elements, i would have used in several place to remove duplicate elements
          const commentsText = commentarray
            .map((item) => `${item}`)
            .join("<br>");

          comments.innerHTML = commentsText;
          comments.style.maxHeight = "200px";
          comments.style.overflowY = "auto";
          const ingredientarray = [
            ...new Set(data.map((item) => item.ingredient)),
          ];
          const ingredientlist = document.querySelector(
            ".ingredientsforselected"
          );

          ingredientlist.innerHTML = "";
          const box = document.createElement("div");
          const text = ingredientarray.map((item) => `${item}`).join("<br>");
          box.style.fontWeight = "bold";
          box.innerHTML = text;
          ingredientlist.appendChild(box);
          const rating = document.querySelector(".ratingfordish");
          rating.innerHTML = ""; // Clear previous comments
          const ratingarray = [
            ...new Set(
              data.map((item) => `${item.username}:  ${item.rating}\u2605`)
            ),
          ];
          const boxrating = document.createElement("div");
          const textrating = ratingarray.map((item) => `${item}`).join("<br>");
          boxrating.innerHTML = textrating;
          rating.appendChild(boxrating);
          rating.style.maxHeight = "200px";
          rating.style.overflowY = "auto";
          currentrecipe = data[0].id;
          console.log(ingredientarray);
          const targetElement = document.querySelector(".showrecipe");
          window.scrollTo({
            top: targetElement.offsetTop,
            behavior: "smooth",
          });
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      });
    });
  }
  //function for fetching and displaying based on the recipes which are given by backend for our filter
  async function fetchAndDisplayRecipes() {
    const diet = [];
    const cuisine = [];

    dietlist.forEach((object) => {
      if (object.checked) {
        diet.push(object.value);
      }
    });

    cuisinelist.forEach((cuisines) => {
      if (cuisines.checked) {
        cuisine.push(cuisines.value);
      }
    });

    const requestData = {
      diet: diet,
      cuisine: cuisine,
      time: parseInt(timefinalised), // Ensure timefinalised is parsed correctly
      ingredients: finalingredients, // Assuming finalingredients is defined somewhere
    };

    console.log("Request Data:", requestData);

    try {
      const response = await fetch("/getRecipes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(requestData),
      });

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const data = await response.json();

      const recipeContainer = document.querySelector(".ingredientslist");
      recipeContainer.innerHTML = ""; // Clear previous results

      if (!Array.isArray(data)) {
        throw new Error("Received data is not an array");
      }

      data.forEach((recipe) => {
        const recipeDiv = document.createElement("div");
        recipeDiv.classList.add("recipe");
        recipeDiv.style.backgroundImage =
          "linear-gradient(to right, rgb(6, 4, 67), rgba(8, 248, 204, 0.986))";
        recipeDiv.style.border = "2px solid white";
        recipeDiv.style.color = "white";
        recipeDiv.style.height = "155px";
        recipeDiv.style.margin = "2px";
        const recipeTitle = document.createElement("h3");
        recipeTitle.classList.add("recipename");
        recipeTitle.textContent = recipe.name;
        const img = document.createElement("img");
        img.src = `${recipe.image_path}`;
        img.alt = "";
        img.style.float = "right";
        img.style.height = "100%";
        img.style.width = "25%";
        recipeTitle.style.fontSize = "32px";
        recipeTitle.style.fontWeight = "bold";
        const recipeDetails = document.createElement("p");
        recipeDetails.style.fontSize = "25px";
        recipeDetails.textContent = `Cuisine: ${recipe.cuisine}, Preparation Time: ${recipe.preparation_time} minutes`;
        recipeDetails.style.fontStyle = "italic";
        recipeDiv.appendChild(img);
        recipeDiv.appendChild(recipeTitle);
        recipeDiv.appendChild(recipeDetails);
        recipeContainer.appendChild(recipeDiv);
        recipeContainer.style.maxHeight = "550px";
        recipeContainer.style.overflowY = "auto";
        recipeDiv.setAttribute("data-recipe-id", recipe.id);
      });

      // Add event listeners after recipes are rendered
      addRecipeClickListeners();
    } catch (error) {
      console.error("Error fetching recipes:", error);
    }
  }

  // Submit button event
  document.querySelector(".submitfinal").addEventListener("click", (e) => {
    e.preventDefault(); // Prevent default form submission if this is inside a form

    const dietlist = document.querySelectorAll(".diet-checkbox"); // Ensure correct selectors
    const cuisinelist = document.querySelectorAll(".cuisine-checkbox"); // Ensure correct selectors

    fetchAndDisplayRecipes();
  });

  // Function to fetch and display recipes

  const stars = document.querySelectorAll(".star");
  stars.forEach((star) => {
    star.addEventListener("click", () => {
      const value = star.getAttribute("data-value");

      // Remove selected class from all stars
      stars.forEach((s) => s.classList.remove("selected"));

      // Add selected class to the clicked star and all previous stars
      star.classList.add("selected");
      let previousStar = star.previousElementSibling;
      while (previousStar) {
        previousStar.classList.add("selected");
        previousStar = previousStar.previousElementSibling;
      }

      // Log the rating value to the console
      rating = value;
    });
  });

  const like = document.querySelector(".heart-button");
  like.addEventListener("click", (event) => {
    if (!like.classList.contains("liked")) {
      like.innerHTML = "";
      const red = document.createElement("img");
      red.src = "../readheart.png";
      like.classList.add("liked");
      red.height = 100;
      red.width = 135;
      like.appendChild(red);
      const agree = window.confirm("Do you want to save the recipe?");
      if (agree) {
        fetch("/save-recipe", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ userId, recipeid }),
        })
          .then((response) => response.json())
          .then((data) => {
            console.log("Recipe saved for user:", data.userId);
            console.log("Recipe ID:", data.recipeid);
            alert(data.message);
            document.querySelector(".heart-button").style.display = "none";
          })
          .catch((error) => {
            console.error("Error saving recipe:", error);
            alert("you can't save same recipe twice");
          });
      } else {
        console.log("Recipe not saved.");
        alert("you can't save same recipe twice");
      }
    }
  });
  //this is for making review and comments;
  const reviewbutton = document.getElementById("userreviewbutton");
  reviewbutton.addEventListener("click", () => {
    const review = document.querySelector("#userreview");
    console.log(currentrecipe);
    console.log(userId);
    console.log(review.value);
    console.log(rating);

    const postData = {
      recipe_id: currentrecipe,
      user_id: userId,
      comment: review.value,
      rating: rating,
    };

    fetch("/comments", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(postData),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Success:", data);
        alert(data.message);
        // Optionally update UI or display a success message
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  });

  // Function to make the voice over , for procedure;
  const speakButton = document.querySelector(".read");
  const pauseButton = document.getElementById("pauseButton");
  const resumeButton = document.getElementById("resumeButton");

  let utterance;

  if (!window.speechSynthesis) {
    alert("Sorry, your browser does not support speech synthesis.");
    return;
  }
  speakButton.addEventListener("click", () => {
    const paragraph = document.querySelector(".procedure").innerText;
    utterance = new SpeechSynthesisUtterance(paragraph);

    // Start new speech
    // Optionally, you can set some properties of the utterance
    utterance.lang = "en-US"; // Language and accent
    utterance.pitch = 1; // 0 to 2, default is 1
    utterance.rate = 1; // 0.1 to 10, default is 1
    utterance.volume = 1; // 0 to 1, default is 1

    window.speechSynthesis.speak(utterance);
  });

  pauseButton.addEventListener("click", () => {
    if (window.speechSynthesis.speaking && !window.speechSynthesis.paused) {
      window.speechSynthesis.pause();
    }
  });

  resumeButton.addEventListener("click", () => {
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }
  });
});

// adding function to view the displayed liked recipes when it is clicked
opennav = document.getElementById("mySidenav");
const viewsaved = document.querySelector(".savedrecipe");

viewsaved.addEventListener("click", (e) => {
  opennav.style.width = "0";
  window.speechSynthesis.cancel();
  let currentrecipe;
  function addRecipeClickListeners() {
    const recipes = document.querySelectorAll(".recipe");
    const showrecipe = document.querySelector(".showrecipe");

    recipes.forEach((object) => {
      object.addEventListener("click", async (event) => {
        window.speechSynthesis.cancel();
        showrecipe.style.display = "block";
        if (object.classList.contains("saved")) {
          // for not displaying the saving symbol for already liked recipe, even if we try to relike, we cant , becaus
          // the backend accepts like only if recipe and user set is distinct from their history;
          document.querySelector(".heart-button").style.display = "none";
        }
        const recipeId = object.getAttribute("data-recipe-id");
        recipeid = recipeId;
        try {
          const response = await fetch(`/recipe/${recipeId}`);
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          data = await response.json();
          console.log(data);
          data = Array.from(data);
          console.log(data);
          const recipetitle = document.querySelector(".recipetitle");
          recipetitle.textContent = data[0].name;
          const recipeimage = document.querySelector(".recipeimage");
          let img = document.createElement("img");
          img.src = `${data[0].image_path}`;
          img.alt = "recipe image";
          recipeimage.innerHTML = "";
          recipeimage.appendChild(img);
          const recipesteps = document.querySelector(".procedure");

          recipesteps.textContent = data[0].steps;
          const comments = document.querySelector(".commentsfordish");

          comments.innerHTML = ""; // Clear previous comments
          const commentarray = [
            ...new Set(
              data.map((item) => `${item.username}:  ${item.comment}`)
            ),
          ];
          const commentsText = commentarray
            .map((item) => `${item}`)
            .join("<br>");
          comments.innerHTML = commentsText;
          comments.style.maxHeight = "200px";
          comments.style.overflowY = "auto";
          const ingredientarray = [
            ...new Set(data.map((item) => item.ingredient)),
          ];
          const ingredientlist = document.querySelector(
            ".ingredientsforselected"
          );
          ingredientlist.innerHTML = "";

          const box = document.createElement("div");
          const text = ingredientarray.map((item) => `${item}`).join("<br>");
          box.innerHTML = text;
          ingredientlist.appendChild(box);
          const rating = document.querySelector(".ratingfordish");

          rating.innerHTML = ""; // Clear previous comments
          const ratingarray = [
            ...new Set(
              data.map((item) => `${item.username}:  ${item.rating} \u2605`)
            ),
          ];
          const boxrating = document.createElement("div");
          const textrating = ratingarray.map((item) => `${item}`).join("<br>");
          boxrating.innerHTML = textrating;
          rating.appendChild(boxrating);
          rating.style.maxHeight = "200px";
          rating.style.overflowY = "auto";
          currentrecipe = data[0].id;
          console.log(ingredientarray);
          const targetElement = document.querySelector(".showrecipe");
          window.scrollTo({
            top: targetElement.offsetTop,
            behavior: "smooth",
          });
        } catch (error) {
          console.error("Error fetching data:", error);
        }
      });
    });
  }
  //for displaying the liked recipe in index page
  async function displayliked() {
    try {
      const userId = window.location.pathname.split("/").pop();
      const response = await fetch(`/saved-recipes/${userId}`, {
        method: "GET", // Use GET method for fetching data
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      const data = await response.json();

      const recipeContainer = document.querySelector(".ingredientslist");
      recipeContainer.innerHTML = ""; // Clear previous results

      if (!Array.isArray(data)) {
        throw new Error("Received data is not an array");
      }
      const savedtitle = document.createElement("div");
      savedtitle.textContent = "Saved Recipes ❤️";
      recipeContainer.appendChild(savedtitle);
      savedtitle.classList.add("savedtitle");
      data.forEach((recipe) => {
        const recipeDiv = document.createElement("div");
        recipeDiv.classList.add("recipe");
        recipeDiv.classList.add("saved");
        recipeDiv.style.backgroundImage =
          "linear-gradient(to right, rgb(6, 4, 67), rgba(8, 248, 204, 0.986))";
        recipeDiv.style.color = "white";
        recipeDiv.style.height = "155px";
        recipeDiv.style.border = " white 2px solid";
        recipeDiv.style.margin = "2px";

        const img = document.createElement("img");
        img.src = `${recipe.image_path}`;
        img.alt = "";
        img.style.float = "right";
        img.style.height = "100%";
        img.style.width = "25%";
        const recipeTitle = document.createElement("h3");
        recipeTitle.classList.add("recipename");
        recipeTitle.textContent = recipe.name;
        recipeTitle.style.fontSize = "32px";
        recipeTitle.style.fontWeight = "bold";
        recipeid = recipe.id;
        const recipeDetails = document.createElement("p");
        recipeDetails.style.fontSize = "25px";
        recipeDetails.textContent = `Cuisine: ${recipe.cuisine}, Preparation Time: ${recipe.preparation_time} minutes`;
        recipeDetails.style.fontStyle = "italic";
        recipeDiv.appendChild(img);
        recipeDiv.appendChild(recipeTitle);
        recipeDiv.appendChild(recipeDetails);
        recipeContainer.appendChild(recipeDiv);
        recipeContainer.style.maxHeight = "550px";
        recipeContainer.style.overflowY = "auto";
        recipeDiv.setAttribute("data-recipe-id", recipe.id);
      });

      // Add event listeners after recipes are rendered
      console.log("eventclickelistener");
      addRecipeClickListeners();
    } catch (error) {
      console.error("Error fetching recipes:", error);
    }
  }

  displayliked();
});
